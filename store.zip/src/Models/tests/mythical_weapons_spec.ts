// import { Weapon, mythicalWeaponStore } from "../mythical_weapons";

// const store = new mythicalWeaponStore();

// describe("mythical weapon model", () => {
//   it("should have an index method", () => {
//     expect(store.index).toBeDefined();
//   });
//   it("index method should return a list of items", async () => {
//     const res = await store.index();
//     expect(res).toEqual([]);
//   });
// });
